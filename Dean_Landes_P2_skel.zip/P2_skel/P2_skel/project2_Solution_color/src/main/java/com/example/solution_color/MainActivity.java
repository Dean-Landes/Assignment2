package com.example.solution_color;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.library.bitmap_utilities.BitMap_Helpers;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity  {

    //private static final String PROCESSED_FILE = "Processed File";
    ImageView backgroundPic;
    ImageView cameraIcon;
    final int CAMERA_PICTURE_REQUEST = 2;
    private final int SHARE_CODE = 100;
    private Bitmap originalPic, extraPic;
    Bitmap colorizedPic, sketchedPic;
    private int screenheight;
    private int screenwidth;
    private Uri uriFile;
    private final String file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/picture.jpg";
    //private final String capturedFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pictureSaved.jpg";
    private BitmapFactory.Options bmpf_opt = new BitmapFactory.Options();
    private int ImageHeight = bmpf_opt.outHeight;
    private int ImageWidth = bmpf_opt.outWidth;
    String imageType = bmpf_opt.outMimeType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        backgroundPic = (ImageView)findViewById(R.id.backgroundPic);
        cameraIcon = (ImageView)findViewById(R.id.camera);
        //Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFile);
        cameraIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFile);
                startActivityForResult(intent, CAMERA_PICTURE_REQUEST);
            }
        });

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        screenheight = metrics.heightPixels;
        screenwidth = metrics.widthPixels;

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        File f = new File(file);
        originalPic = Camera_Helpers.loadAndScaleImage(file, screenheight, screenwidth);
        backgroundPic.setImageBitmap(originalPic);
        bmpf_opt.inSampleSize = 4;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.settings:
                Intent settingsIntent = new Intent(this, SettingsActivity.class);
                startActivity(settingsIntent);
                break;
            case R.id.reset:
                doReset();
                break;
            case R.id.edit:
                if(originalPic == null) {
                    break;
                }
                else {
                    backgroundPic(doSketch());
                    break;
                }
            case R.id.colorize:
                if(originalPic == null) {
                    break;
                }
                else {
                    backgroundPic(doColorize());
                    break;
                }
            case R.id.share:
                doShare();
                break;
            case R.id.about:
                doHelp();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void backgroundPic(Bitmap bmp) {
        backgroundPic.setImageBitmap(bmp);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_XY);
    }

    public void doShare() {
        Intent shareBitmap = new Intent(Intent.ACTION_SEND);
        //shareBitmap.setAction(Intent.ACTION_SEND);
        File filePic = new File(this.file);
        //Uri imagePath = Uri.fromFile(filePic);
        shareBitmap.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(filePic));
        //SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        //shareBitmap.putExtra(Intent.EXTRA_SUBJECT, pref.getString(getString(R.string.message_subject), ""));
        //shareBitmap.putExtra(Intent.EXTRA_TEXT, pref.getString(getString(R.string.message_text), ""));
        shareBitmap.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.message_subject));
        shareBitmap.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.message_text));
        shareBitmap.putExtra(Intent.EXTRA_EMAIL, new String[]{getString(R.string.test_email)});
        shareBitmap.setType(getString(R.string.image_type));
        //Bitmap extra_copy = BitMap_Helpers.copyBitmap(backgroundPic.getDrawable());
        //Camera_Helpers.saveProcessedImage(extra_copy, file);
        /*
        if(!filePic.exists()) {
            try {
                filePic.createNewFile();
            }
            catch (IOException e)
            {

            }
        }*/
        //Uri imagePath = Uri.fromFile(filePic);
        //shareBitmap.putExtra(Intent.EXTRA_STREAM, imagePath);
        startActivityForResult(shareBitmap, CAMERA_PICTURE_REQUEST);
        /*
        startActivityForResult(Intent.createChooser(shareBitmap, "Share you on this"), SHARE_CODE);
        backgroundPic.setImageBitmap(originalPic);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_XY);*/
    }

    public void doReset() {
        Camera_Helpers.delSavedImage(file);
        backgroundPic.setImageResource(R.drawable.gutters);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_XY);
    }

    public void doHelp(){
        // Create out AlterDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("This is where the help screen goes");
        //create an anonymous class that is listening for button click
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            /**
             * This method will be invoked when a button in the dialog is clicked.
             * Note the @override
             * Note also that I have to scope the context in the toast below, thats because anonymous
             * * classes have a reference to the class they were declared in accessed via Outerclassname.this
             *
             * @param dialog The dialog that received the click.
             * @param which  The button that was clicked (e.g.
             *               {@link DialogInterface#BUTTON1}) or the position
             */
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "clicked OK in Help", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private Bitmap doSketch() {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

        int sketchiness = pref.getInt(getString(R.string.sketch), 25);
        sketchedPic = BitMap_Helpers.thresholdBmp(originalPic, sketchiness);
        extraPic = sketchedPic;
        Camera_Helpers.saveProcessedImage(extraPic, file);
        //backgroundPic.setImageBitmap(sketchedPic);
        //backgroundPic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        //backgroundPic.setScaleType(ImageView.ScaleType.FIT_XY);
        return extraPic;
    }

    private Bitmap doColorize() {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences((MainActivity.this));
        colorizedPic = colorizeImage(originalPic);
        Camera_Helpers.saveProcessedImage(colorizedPic, file);
        extraPic = colorizedPic;
        /*final int colorize = pref.getInt("Color_Level", 50);
        final int sketchiness = pref.getInt(getString(R.string.sketch), 25);
        sketchedPic = BitMap_Helpers.thresholdBmp(originalPic, sketchiness);
        colorizedPic = BitMap_Helpers.colorBmp(originalPic, colorize);
        BitMap_Helpers.merge(originalPic, sketchedPic);
        backgroundPic.setImageBitmap(colorizedPic);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_XY);
        */
        return extraPic;
    }

    public Bitmap colorizeImage(Bitmap bitem) {
        Bitmap sketchybmp = BitMap_Helpers.thresholdBmp(bitem, Integer.parseInt(getResources().getString(R.string.sketch)));
        Bitmap saturatedbmp = BitMap_Helpers.colorBmp(bitem, Integer.parseInt(getString(R.string.saturate)));
        BitMap_Helpers.merge(saturatedbmp, sketchybmp);
        return saturatedbmp;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CAMERA_PICTURE_REQUEST) {
            if(resultCode == Activity.RESULT_OK) {
                originalPic = Camera_Helpers.loadAndScaleImage(file, screenheight, screenwidth);
                backgroundPic.setImageBitmap(originalPic);
                backgroundPic.setScaleType(ImageView.ScaleType.FIT_CENTER);
                backgroundPic.setScaleType(ImageView.ScaleType.FIT_XY);
            }
            if(resultCode == Activity.RESULT_CANCELED){
                Toast.makeText(this, "photo saving was canceled", Toast.LENGTH_SHORT);
            }
        }

        //Bitmap bp = (Bitmap) data.getExtras().get("data");
        //backgroundPic.setImageBitmap(bp);

    }

    private void takePicture(View view) {
        Intent intentPic = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intentPic.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(file)));
        startActivityForResult(intentPic, CAMERA_PICTURE_REQUEST);
        backgroundPic.setImageBitmap(originalPic);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        backgroundPic.setScaleType(ImageView.ScaleType.FIT_XY);
    }
}

